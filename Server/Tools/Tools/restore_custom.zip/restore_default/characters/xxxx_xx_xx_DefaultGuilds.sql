USE characters;

-- ######################################################--
--	DEFAULT GUILDS
-- ######################################################--

-- *** WARNING ***
-- Player GUIDS 1 and 2 must be present before this will properly execute!
-- *** WARNING ***

-- Horde - Adventure - GMGuid: 1
DELETE FROM `guild` WHERE `guildid`=1;
INSERT INTO `guild` (`guildid`, `name`, `leaderguid`, `EmblemStyle`, `EmblemColor`, `BorderStyle`, `BorderColor`, `BackgroundColor`, `info`, `motd`, `createdate`, `BankMoney`) VALUES (1, 'For The Horde', 1, 166, 14, 1, 14, 44, 'Example Horde Guild', 'Welcome to For The Horde!', 1498723958, 1631737106);

-- Alliance - Caress of Steel - GMGuid: 2
DELETE FROM `guild` WHERE `guildid`=2;
INSERT INTO `guild` (`guildid`, `name`, `leaderguid`, `EmblemStyle`, `EmblemColor`, `BorderStyle`, `BorderColor`, `BackgroundColor`, `info`, `motd`, `createdate`, `BankMoney`) VALUES (2, 'For The Alliance', 2, 112, 3, 5, 3, 35, 'Example Alliance Guild', 'Welcome to For The Alliance!', 1499669732, 749909976);
