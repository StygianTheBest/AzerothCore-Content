/*
Navicat MySQL Data Transfer

Source Server         : AZC
Source Server Version : 50628
Source Host           : 127.0.0.1:3306
Source Database       : default_auth

Target Server Type    : MYSQL
Target Server Version : 50628
File Encoding         : 65001

Date: 2017-10-09 16:56:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `sha_pass_hash` varchar(40) NOT NULL DEFAULT '',
  `sessionkey` varchar(80) NOT NULL DEFAULT '',
  `v` varchar(64) NOT NULL DEFAULT '',
  `s` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='Account System';

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1', 'test1', '047ce22643f9b0bd6baeb18d51bf1075a4d43fc6', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('2', 'test2', '10eb1ff16cf5380147e8281cd8080a210ecb3c53', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('3', 'test3', 'e546bbf9ca93ae5291f0b441bb9ea2fa0c466176', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('4', 'test4', '61015d83b456a9c6a7defdff07f55265f24097af', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('5', 'test5', 'dddeac4ffe5f286ec57b7a1ed63bf3a859debe1e', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('6', 'test6', 'f1f94cdffd83c8c4182d66689077f92c807ab579', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('7', 'test7', '6fcd35c35b127be1d9ca040b2b478eb366506ce2', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('8', 'test8', '484332ccb02e284e4e0a04573c3fa417f4745fdf', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('9', 'test9', '4fce15ed251721f02754d5381ae9d0137b6a6a30', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');
INSERT INTO `account` VALUES ('10', 'test10', 'b22d249228e84ab493b39a2bd765bee9b7c0b350', '', '', '', '', '2016-01-30 16:09:43', '127.0.0.1', '0', '0', '0000-00-00 00:00:00', '0', '2', '0', '', '', '0', '', '0');

-- ----------------------------
-- Table structure for account_access
-- ----------------------------
DROP TABLE IF EXISTS `account_access`;
CREATE TABLE `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_access
-- ----------------------------
INSERT INTO `account_access` VALUES ('1', '4', '-1');
INSERT INTO `account_access` VALUES ('2', '4', '-1');
INSERT INTO `account_access` VALUES ('3', '4', '-1');
INSERT INTO `account_access` VALUES ('4', '4', '-1');
INSERT INTO `account_access` VALUES ('5', '4', '-1');
INSERT INTO `account_access` VALUES ('6', '4', '-1');
INSERT INTO `account_access` VALUES ('7', '4', '-1');
INSERT INTO `account_access` VALUES ('8', '4', '-1');
INSERT INTO `account_access` VALUES ('9', '4', '-1');
INSERT INTO `account_access` VALUES ('10', '4', '-1');

-- ----------------------------
-- Table structure for account_banned
-- ----------------------------
DROP TABLE IF EXISTS `account_banned`;
CREATE TABLE `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';

-- ----------------------------
-- Records of account_banned
-- ----------------------------

-- ----------------------------
-- Table structure for autobroadcast
-- ----------------------------
DROP TABLE IF EXISTS `autobroadcast`;
CREATE TABLE `autobroadcast` (
  `realmid` int(11) NOT NULL DEFAULT '-1',
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `weight` tinyint(3) unsigned DEFAULT '1',
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`,`realmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of autobroadcast
-- ----------------------------

-- ----------------------------
-- Table structure for ip_banned
-- ----------------------------
DROP TABLE IF EXISTS `ip_banned`;
CREATE TABLE `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Banned IPs';

-- ----------------------------
-- Records of ip_banned
-- ----------------------------

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `time` int(10) unsigned NOT NULL,
  `realm` int(10) unsigned NOT NULL,
  `type` varchar(250) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `string` text CHARACTER SET latin1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of logs
-- ----------------------------

-- ----------------------------
-- Table structure for realmcharacters
-- ----------------------------
DROP TABLE IF EXISTS `realmcharacters`;
CREATE TABLE `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Realm Character Tracker';

-- ----------------------------
-- Records of realmcharacters
-- ----------------------------

-- ----------------------------
-- Table structure for realmlist
-- ----------------------------
DROP TABLE IF EXISTS `realmlist`;
CREATE TABLE `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '12340',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Realm System';

-- ----------------------------
-- Records of realmlist
-- ----------------------------
INSERT INTO `realmlist` VALUES ('1', 'AzerothCore', '127.0.0.1', '127.0.0.1', '255.255.255.0', '8085', '0', '2', '1', '0', '0', '12340');

-- ----------------------------
-- Table structure for version_db_auth
-- ----------------------------
DROP TABLE IF EXISTS `version_db_auth`;
CREATE TABLE `version_db_auth` (
  `sql_rev` varchar(100) NOT NULL,
  `required_rev` varchar(100) DEFAULT NULL,
  `2016_09_04_00` bit(1) DEFAULT NULL,
  PRIMARY KEY (`sql_rev`),
  KEY `required` (`required_rev`),
  CONSTRAINT `required` FOREIGN KEY (`required_rev`) REFERENCES `version_db_auth` (`sql_rev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of version_db_auth
-- ----------------------------
